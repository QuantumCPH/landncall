<h1>Zapna Global &#8211; FAQ</h1>
<p>Hoved regler for support af mobil telefoner til Zapna Global:</p>

<ul>
	<li>Vi underst&oslash;tter generelt alle Nokia, Andriod, Iphone, Sony ericsson 
  telefoner</li>
  <li>Windows mobil telefoner kan vi ikke generelt sige at vi unders&oslash;tter 
  alle modeller da de opf&oslash;rer sig anderledes &#8211; f&oslash;lg vejledning 
  og check telefonen inden du giver kortet til kunden</li>
  <li>Vi underst&oslash;tter ikke 3 selskabs kunder da deres simkort kun kan 
  k&oslash;rer p&aring; UTMS</li>
	<li>
	  Nokia telefoner skal n&aelig;sten altid manuelt restartes n&aring;r 
	  man skifter fra Zapna Global til eksisterende simkort
	</li>
</ul>

<ol>
	<li>
		<p>Hvordan fungerer Zapna Global?</p>
		<p>Svar: Zapna Global fungerer ved at du v&aelig;lger et nummer fra telefonbogen 
  eller indtaster nummeret direkte, og ringer op. Telefonen bliver lagt p&aring; 
  og 5-7 sekunder efter bliver du ringet op som du besvarer og du bliver forbundet.</p>
	</li>
	<li>
		<p>N&aring;r jeg skifter til Zapna Global, skifter min menuer til engelsk</p>
		<p>Svar: Dette skyldes at SIM-kortet er programmeret til et start-op med engelsk 
  menu, for at &aelig;ndre dette skal du g&oslash;re f&oslash;lgende:</p>
  		<ul>
			<li>G&aring; ind i hovedmenu</li>
			<li>V&aelig;lg &#8221;v&aelig;rkt&oslash;jer&#8221; / &#8221;indstilling&#8221;</li>
			<li>V&aelig;lg &#8221;Telefon&#8221;</li>
			<li>V&aelig;lg &#8221;generelt&#8221;</li>
			<li>V&aelig;lg &#8221;sprog p&aring; telefon&#8221;</li>
			<li>V&aelig;lg &#8221;dansk&#8221;</li>	
		</ul>
		<p>Hermed vil menuerne v&aelig;re p&aring; dansk, hver gang du skifter til Zapna 
  global</p>
	</li>
	<li>
		<p>N&aring;r jeg ringer op f&aring;r jeg en meddelelse &#8221; Opkaldet er ikke 
  tilladt&#8221; men telefonen ringer alligevel, hvad skyldes dette?</p>
		<p>Svar: Du skal ignorer denne besked.</p>
	</li>
	<li>
		<p>N&aring;r jeg ringer ud f&aring;r jeg denne besked &#8221;Det er ikke muligt 
  at tilbyde den &oslash;nskede service&#8221;</p>
		<p>Svar: Dette kan skyldes at ops&aelig;tningen p&aring; dit SIM-kort er forkert 
  sat op.</p>
  		<ul>
			<li>G&aring; ind i hovedmenu og v&aelig;lg &#8221;zapna&#8221;</li>
			<li>V&aelig;lg &#8221;dial format&#8221;</li>
			<li>V&aelig;lg &#8221;Activate&#8221;</li>
		</ul>
		<p>Herefter er det muligt at ringe ud.</p>
	</li>
	<li>
		<p>Hvordan kan jeg aflytte min telefonsvare?</p>
		<p>Svar: N&aring;r du er p&aring; dit global SIM-kort skal du indtaste *151# for 
  at komme ind til din telefonsvarer. Herefter kan du aflytte beskeden ved at 
  trykke &#8221;1&#8221;</p>
	</li>
	<li>
		<p>N&aring;r jeg skifter fra eksisterende SIM-kort og til Global kortet bliver 
  viderestillingen ikke aktiveret?</p>
		<p>Svar: Unders&oslash;g med din mobil operat&oslash;r om du har mulighed for at 
  lave ubetinget viderestilling. S&aring;fremt ikke, s&aring; skal du have dette 
  aktiveret inden du kan f&aring; aktiveret viderestilling n&aring;r du skifter 
  til Zapna Global.</p>
	</li>
	<li>
		<p>Skal jeg betale for at lave ubetinget viderestilling</p>
		<p>Svar: Ja, men det er forskelligt, sp&oslash;rger dit teleselskab hvad dette 
  vil koste.</p>
	</li>
	<li>
		<p>N&aring;r jeg skifter tilbage til eksisterende SIM-kort bliver min viderestilling 
  ikke de-aktiveret med det samme?<br>
  Svar: Der kan g&aring; op til 5-6 minutter inden viderestillingen bliver de-aktiveret. 
  Enkelte telefoner underst&oslash;tter ikke automatisk de-aktivering af viderestillingen, 
  derfor er du n&oslash;dsaget til at g&oslash;re dette manuelt. Dette g&oslash;re 
  du ved at:</p>
  		<ul>
			<li>G&aring; ind i hovedmenu</li>
			<li>V&aelig;lg &#8221;v&aelig;rkt&oslash;jer&#8221; / &#8221;indstilling&#8221;</li>
			<li>V&aelig;lg &#8221;omstilling&#8221;</li>
			<li>V&aelig;lg &#8221;taleopkald&#8221;</li>
			<li>V&aelig;lg &#8221; alle taleopkald&#8221;</li>
			<li>V&aelig;lg &#8221;annuller&#8221;</li>
			
		</ul>
		<p>Herved vil din viderestilling blive annulleret.</p>
	</li>
	<li>
		<p>Jeg har fjernet Zapna Global fra min SIM-kort, men min telefon er stadig 
  viderestillet til Zapna global hvordan fjerner jeg viderestillingen.</p>
		<p>Svar: Se sp&oslash;rgsm&aring;l 8.</p>
	</li>
	<li>
		<p>Hvorfor vises der et engelsk nummer n&aring;r jeg ringer til nogen fra min 
  Zapna Global kort</p>
		<p>Svar: Dette skyldes at vores l&oslash;sning og vores roaming server st&aring;r 
  i England.</p>
	</li>
	<li>
		<p>Kan jeg sende sms fra min Zapna Global kort</p>
		<p>Svar: Ja det er muligt at sende sms fra dit kort</p>
	</li>
	<li>
		<p>Vil det ogs&aring; v&aelig;re det engelske nummer der st&aring;r som afsender 
  n&aring;r jeg sender sms?</p>
		<p>Svar: Ja, det vil det g&oslash;re.</p>
	</li>
	<li>
		<p>Vil det s&aring; koste udlands sms takst, hvis min familie sender sms til 
  mig p&aring; det engelske nummer?</p>
		<p>Svar: Ja, de vil betale udlands sms takst for at sende sms til det engelske 
  nummer.</p>
	</li>
	<li>
		<p>Kan jeg sende sms fra min Danske mobil nummer?</p>
		<p>Svar: Ja, men det vil kr&aelig;ve at du skifter tilbage til dit eksisterende 
  nummer, og sender og modtager sms fra det.</p>
	</li>
	<li>
		<p>Kan jeg viderestille mine sms&#8217;er fra min eksisterende SIM-kort til 
  Zapna Global kort?</p>
		<p>Svar: Nej desv&aelig;rre, teleselskaberne underst&oslash;tter ikke dette funktion.</p>
	</li>
	<li>
		<p>Kan man benytte DATA i udlandet?</p>
		<p>Svar: Nej, det er desv&aelig;rre pt. ikke muligt at benytte DATA n&aring;r du 
  er i udlandet.</p>
	</li>
	<li>
		<p>N&aring;r jeg skifter tilbage til mit eksisterende SIM-kort f&aring;r jeg 
  besked &#8221;SIM-kort&#8221; kan ikke registreres?</p>
		<p>Svar: Dette kan l&oslash;ses ved at &aelig;ndre din netv&aelig;rks ops&aelig;tning.</p>
		
  		<p>Det g&oslash;re du ved at:</p>
		<ul>
			<li>G&aring; ind i hovedmenu:</li>
			<li>V&aelig;lg &#8221;v&aelig;rkt&oslash;jer&#8221; / &#8221;indstilling&#8221;</li>
			<li>V&aelig;lg &#8221;netv&aelig;rk&#8221;</li>
			<li>V&aelig;lg &#8221;netv&aelig;rk tilstand&#8221;</li>
			<li>V&aelig;lg &#8221;GSM&#8221;</li>
		</ul>
	</li>
	<li>
		<p>Vil Zapna Out tage over n&aring;r jeg ringer til udlandet fra Danmark?</p>
		<p>Svar: Ja, n&aring;r du er i Danmark og skal ringe til udlandet vil zapna automatisk 
  tage over, og opkaldet k&oslash;rer igennem Zapna.</p>
	</li>
	<li>
		<p>N&aring;r jeg er i udlandet og jeg ikke har aktiveret Zapna global, vil 
  Zapna out ogs&aring; tage over mit opkald hvis jeg ringer til et internationalt 
  nummer?</p>
		<p>Svar: Nej, du vil ringe ud direkte via din eksisterende mobil operat&oslash;r.</p>
	</li>
	<li>
		<p>Jeg har 3g SIM-kort, kan jeg bruge Zapna Global?</p>
		<p>Svar: Nej, desv&aelig;rre underst&oslash;tter vi pt. Ikke 3g SIM-kort, og 3 
  mobil</p>
	</li>
	<li>
		<p>Kan jeg benytte Zapna Global hvis min telefon er SIM-kode l&aring;st?</p>
		<p>Svar: Nej, SIM-kortet vil fungere som et helt almindeligt SIM-kort.</p>
	</li>
	<li>
		<p>Kan jeg benytte min kontakter fra sim-kortet n&aring;r jeg skifter til Zapna 
  Global</p>
		<p>Svar: Nej, du er n&oslash;d til at gemme alle dine kontakter p&aring; mobilen 
  telefonen</p>
	</li>
</ol>