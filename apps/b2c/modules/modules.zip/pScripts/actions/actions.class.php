<?php

/**
 * scripts actions.
 *
 * @package    zapnacrm
 * @subpackage scripts
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php,v 1.3 2010-08-18 06:06:25 orehman Exp $
 */
class pScriptsActions extends sfActions
{
 /**
  * Executes index action
  *
  * @param sfRequest $request A request object
  */
  public function executeIndex(sfWebRequest $request)
  {
    $this->forward('default', 'module');
  }
  
  public function executeAutoRefill(sfWebRequest $request)
  {
  	
  	//get customers to refill
  	$c = new Criteria();
  	
  	$c->add(CustomerPeer::CUSTOMER_STATUS_ID, sfConfig::get('app_status_completed'));
  	$c->add(CustomerPeer::AUTO_REFILL_AMOUNT, 0, Criteria::NOT_EQUAL);
  	$c->add(CustomerPeer::SUBSCRIPTION_ID, null, Criteria::ISNOTNULL);
  	
  	$c1 = $c->getNewCriterion(CustomerPeer::LAST_AUTO_REFILL, 'TIMESTAMPDIFF(MINUTE, LAST_AUTO_REFILL, NOW()) > 60' , Criteria::CUSTOM);
  	$c2 = $c->getNewCriterion(CustomerPeer::LAST_AUTO_REFILL, null, Criteria::ISNULL);
  	
  	$c1->addOr($c2);
  	
  	$c->add($c1);
  	
  	$epay_con = new EPay();
  	
  	$customer = new Customer();
  	
  	
  	foreach (CustomerPeer::doSelect($c) as $customer) 
  	{
  		//if customer balance is less than 10
  		if (CustomerPeer::getBalance($customer)<$customer->getAutoRefillMinBalance())
  		{
  			//create an order and transaction
  			$customer_order = new CustomerOrder();
  			$customer_order->setCustomer($customer);
  			
  			//select order product
  			$c = new Criteria();
  			$c->add(CustomerProductPeer::CUSTOMER_ID, $customer->getId());
  			$customer_product = CustomerProductPeer::doSelectOne($c);
  			
  			$customer_order->setProduct($customer_product);
  			$customer_order->setQuantity(0);
  			$customer_order->setExtraRefill($customer->getAutoRefillAmount());
  			
  			
  			
  			//create a transaction
  			$transaction = new Transaction();
  			$transaction->setCustomer($customer);
  			$transaction->setAmount($customer->getAutoRefillAmount());
  			$transaction->setDescription('Auto refill');
  			
  			
  			
  			//associate transaction with customer order
  			$customer_order->addTransaction($transaction);
  			
  			//save order to get order_id that is required to create a transaction via epay api
  			$customer_order->save();
  			
			if ($epay_con->authorize(sfConfig::get('app_epay_merchant_number'), $customer->getSubscriptionId(), $customer_order->getId(), $customer->getAutoRefillAmount(), 208, 1))
			{
				$customer_order->setOrderStatusId(sfConfig::get('app_status_completed'));
				$transaction->setTransactionStatusId(sfConfig::get('app_status_completed'));		
			}
			
			$customer_order->save();
			
  			if ( $customer_order->getOrderStatusId()==sfConfig::get('app_status_completed') &&
  					CustomerPeer::recharge($customer, $customer->getAutoRefillAmount())	)
  			{		
  				//send invoices

			  	$message_body = $this->getPartial('customer/order_receipt', array(
			  						'customer'=>$customer,
			  						'order'=>$customer_order,
			  						'transaction'=>$transaction,
			  						'vat'=>0,
			  						'wrap'=>false
			  					));
			  	
			    $subject = $this->getContext()->getI18N()->__('Payment Confirmation');
				$sender_email = sfConfig::get('app_email_sender_email', 'support@zerocall.com');
				$sender_name = sfConfig::get('app_email_sender_name', 'zerocall support');
			
				$recepient_email = trim($this->customer->getEmail());
				$recepient_name = sprintf('%s %s', $this->customer->getFirstName(), $this->customer->getLastName());
				
				
				//send to user
				$email = new EmailQueue($subject, $message_body, $recepient_name, $recepient_email);
				$email->save();
				
				//send to support
				$email2 = new EmailQueue($subject, $message_body, $sender_name, $sender_email);
				$email2->save();
  				
  			}
  			
  		}
  	}
  	
  	$this->forward('default', 'index');
  }
  
  private function run()
  {
  	echo 'run';
  	return true;
  }
  
  public function executeTest(sfWebRequest $request)
  {
  	
  	if (true && $this->run())
  	{
  		echo 'sadi';
  	}
  	
  	echo sha1('test1');
  	
  	exit;
  	
  	$proxyhost = isset($_POST['proxyhost']) ? $_POST['proxyhost'] : '';
	$proxyport = isset($_POST['proxyport']) ? $_POST['proxyport'] : '';
	$proxyusername = isset($_POST['proxyusername']) ? $_POST['proxyusername'] : '';
	$proxypassword = isset($_POST['proxypassword']) ? $_POST['proxypassword'] : '';
  	
	$epay_con = new EPay();
	
	$result = $epay_con->authorize(8884184, 66529, 3923, 400, 208, 1);
	
	if ($result)
		var_dump($result);
	else
		echo "<pre>".$epay_con->getLastError()."</pre>";
	
  	exit;
  	
  	$field_value = '1280820350';
  	$field_value_2 = '1280820403';
  	
  	$date1 = date("Y:m:d H:i:s", $field_value);
  	$date2 = date("Y:m:d H:i:s", $field_value_2);
  	
  	$date_dur = date("H:i:s", $field_value_2-$field_value);
  	
  	echo '<br />';

  	echo sprintf("%s<br />%s<br />%s", $date1, $date2, $date_dur );
  	
  	return sfView::NONE;
  }
  
  public function executeConfirmPayment(sfWebRequest $request)
  {
  	
  	$this->logMessage(print_r($_GET, true));
  	
  	$is_transaction_ok = false;
  	
 	//get the order_id from the session
  	//change the status of that order to complete,
  	//change the customer status to compete too
  	
  	
  	$order_id = $request->getParameter('orderid');
  	$order_amount = ((double)$request->getParameter('amount'))/100;
  	$subscription_id = $request->getParameter('subscriptionid');
  	
  	$this->logMessage('sub id: '.$subscriptioin_id);
  	
  	$this->forward404Unless($order_id || $order_amount);
  	
	//get order object
  	$order = CustomerOrderPeer::retrieveByPK($order_id);

  	//check to see if that customer has already purchased this product
  	$c = new Criteria();
  	$c->add(CustomerProductPeer::CUSTOMER_ID, $order->getCustomerId());
  	$c->addAnd(CustomerProductPeer::PRODUCT_ID, $order->getProductId());
  	//$c->addJoin(CustomerProductPeer::CUSTOMER_ID, CustomerPeer::ID);
  	//$c->addAnd(CustomerPeer::CUSTOMER_STATUS_ID, sfConfig::get('app_status_new'), Criteria::IS_NOT_EQUAL);
  	
  	if (CustomerProductPeer::doCount($c)!=0)
  	{
  		echo 'Customer is already registered.'; 
  		
  		//exit the script successfully
  		return sfView::NONE;
  	}
  	
  	//set subscription id
  	$order->getCustomer()->setSubscriptionId($subscription_id);
  	
  	if ($is_auto_refill_activated = $request->getParameter('USER_ATTR_1')=='1')
  	{
  		$auto_refill_amount = $request->getParameter('USER_ATTR_2');
  		$order->getCustomer()->setAutoRefillAmount($auto_refill_amount);

  		$auto_refill_min_balance = $request->getParameter('USER_ATTR_3');
  		$order->getCustomer()->setAutoRefillMinBalance($auto_refill_min_balance);
  	}
  	
  	//if order is already completed > 404
  	$this->forward404Unless($order->getOrderStatusId()!=sfConfig::get('app_status_completed'));
  	
  	$this->forward404Unless($order);
  	
  	$c = new Criteria;
  	$c->add(TransactionPeer::ORDER_ID, $order_id);
  	
  	$transaction = TransactionPeer::doSelectOne($c);

  	if($transaction->getAmount() > $order_amount || $transaction->getAmount() < $order_amount){
  		//error
  		$order->setOrderStatusId(sfConfig::get('app_status_error')); //error in amount
  		$transaction->setTransactionStatusId(sfConfig::get('app_status_error')); //error in amount
  		$order->getCustomer()->setCustomerStatusId(sfConfig::get('app_status_error')); //error in amount
  		
  	} 
  	else {
  		//TODO: remove it
  		$transaction->setAmount($order_amount);
  		
	  	$order->setOrderStatusId(sfConfig::get('app_status_completed')); //completed
	  	$order->getCustomer()->setCustomerStatusId(sfConfig::get('app_status_completed')); //completed
	  	$transaction->setTransactionStatusId(sfConfig::get('app_status_completed')); //completed
	  	
	  	$is_transaction_ok = true;
  	} 
  	

  	$product_price = $order->getProduct()->getPrice() - $order->getExtraRefill();
  	
  	$product_price_vat = .20 * $product_price;
  	
  	$order->setQuantity(1);
  	
  	//set active agent_package in case customer
  	if ($order->getCustomer()->getAgentCompany())
  	{
  		$order->setAgentCommissionPackageId($order->getCustomer()->getAgentCompany()->getAgentCommissionPackageId());
  	}
	  	
  	
  	$order->save();
  	$transaction->save();

  	if ($is_transaction_ok)
  	{
	  	//set customer's proudcts in use
	  	$customer_product = new CustomerProduct();
	  	
	  	$customer_product->setCustomer($order->getCustomer());
	  	$customer_product->setProduct($order->getProduct());
	  	
	  	$customer_product->save();
	  	
	  	//register to fonet
	  	$this->customer = $order->getCustomer();
	  	
	  	CustomerPeer::registerFonet($this->customer);
	  	
	  	//recharge the extra_refill/initial balance of the prouduct
		CustomerPeer::recharge($this->customer, $order->getExtraRefill());
		
	  	//send email
	  
	  	$message_body = $this->getPartial('payments/order_receipt', array(
	  						'customer'=>$this->customer,
	  						'order'=>$order,
	  						'transaction'=>$transaction,
	  						'vat'=>$product_price_vat,
	  						'wrap'=>true
	  					));
	  	
	    $subject = $this->getContext()->getI18N()->__('Payment Confirmation');
		$sender_email = sfConfig::get('app_email_sender_email', 'support@zerocall.com');
		$sender_name = sfConfig::get('app_email_sender_name', 'zerocall support');
	
		$recepient_email = trim($this->customer->getEmail());
		$recepient_name = sprintf('%s %s', $this->customer->getFirstName(), $this->customer->getLastName());
		
		
		//send to user
		$email = new EmailQueue($subject, $message_body, $recepient_name, $recepient_email);
		$email->save();
		
		//send to support
		$email2 = new EmailQueue($subject, $message_body, $sender_name, $sender_email);
		$email2->save();		

	
	    $this->order = $order;
	  		
  	}
  	else
  	{
  		$this->logMessage('Error in transaction.');
  		
  	} //end if
  	
  	return sfView::NONE;
  }
  
  public function executeProcessCdr(sfWebRequest $request)
  {
  	
  	//list any files in data/new folder
  	
	$cdr_root_dir = 'c:/zerocall_cdr';
	//$cdr_root_dir = 'c:/Inetpub/ftproot/zerocall_cdr';
	
	//TODO: need to fix the new_dir path on server
	$new_dir = $cdr_root_dir;
	$error_dir = $cdr_root_dir.'/error';
	$backup_dir = $cdr_root_dir.'/backup';
	
	
	$files = scandir($new_dir);


	if (count($files)<=2)
	{
		echo 'No file to process in "'.$dir.'"';
		exit(1);
	}
	
	
	//get connection
	$con = Propel::getConnection();
	
	
	foreach ($files as $file)
	{
		$splits = explode('.', $file);
		$file_extension = end($splits);
		
		//start transaction;
		
		if( !( $file=='.' || $file=='..') && ($file_extension=='csv' ) )
		{
			try
			{
			  	$reader = new sfCsvReader($new_dir.'/'.$file);
			  	
			  	$reader->open();
			  	
			  	
			  	//begin transaction
			  	$con->beginTransaction();
			
				while ($data = $reader->read())
				{
					/*
					0	CdrKey
					1	CustomID
					2	AnswerTimeB
					3	EndTimeB
					4	BillSec
					5	BillingTime
					6	Extension
					7	SourceCty
					8	Ani
					9	DestCty
					10	Rounding
					11	UsedValue
					12	InitialAccount
					13	DST_CustomID
					14	DestinationName
					15	COST_RateMatchPhno
					16	COST_DestinationName
					17	COST_RateValue
					18	COST_RateValueFirst
					19	COST_CcsConnectCharge
					20	COST_UsedValue
					21	BZ2_Rate1Minute
					22	BZ1_RateAddMinute
					*/
					
					$cdr_row = new ZerocallCdr();
					
					$cdr_row->setCdrkey($data[0]);
					$cdr_row->setCustomid($data[1]);
					$cdr_row->setAnswertimeb($data[2]);
					$cdr_row->setEndtimeb($data[3]);
					$cdr_row->setBillsec($data[4]);
					$cdr_row->setBillingtime($data[5]);
					$cdr_row->setExtension($data[6]);
					$cdr_row->setSourcecty($data[7]);
					$cdr_row->setAni($data[8]);
					$cdr_row->setDestcty($data[9]);
					$cdr_row->setRounding($data[10]);
					$cdr_row->setUsedvalue($data[11]);
					$cdr_row->setInitialaccount($data[12]);
					$cdr_row->setDstCustomid($data[13]);
					$cdr_row->setDestinationname($data[14]);
					$cdr_row->setCostRatematchphno($data[15]);
					$cdr_row->setCostDestinationname($data[16]);
					$cdr_row->setCostRatevalue($data[17]);
					$cdr_row->setCostRatevaluefirst($data[18]);
					$cdr_row->setCostCcsconnectcharge($data[19]);
					$cdr_row->setCostUsedvalue($data[20]);
					$cdr_row->setBz2Rate1minute($data[21]);
					$cdr_row->setBz1Rateaddminute($data[22]);

					//save the row
					$cdr_row->save($con);
					
				} // end while
				
				$reader->close();	

				
				//commit
				$con->commit();
				

				//move the file to backup
				echo file_exists("$new_dir/$file")?'t':'f';

				rename("$new_dir/$file", "$backup_dir/$file");
				
				//echo is_file("$backup_dir/$file")?'t':'f';
				/*
				if (rename("$new_dir/$file", "$backup_dir/$file"))
				{
					echo ('<p>'.$file . ' has been succesfully moved to backup folder.</p>');
				}
				else
					echo ('<p style="color:red">ERROR MOVING FILE: see for permissions</p>');					
				*/
			}
			catch (Exception $ex)
			{
				//rollback
				$con->rollback();
				
				//move the file to error
				echo $file;
				
				echo file_exists("$new_dir/$file")?'t':'f';
				echo is_dir("$error_dir")?'t':'f';
				
				rename("$new_dir/$file", "$error_dir/$file");

				/*
				if (rename("$new_dir/$file", "$error_dir/$file"))
				{
					echo ('<p style="color:red">Error: '. $file . ' has been moved to error folder.</p>');					
				}
				else
					echo ('<p style="color:red">ERROR MOVING FILE: see for permissions</p>');
				*/

			}
		
			
		} //end if

	} //end for each
	
	echo 'Each CDR is iterated from ' . $new_dir;

  	
  	return sfView::NONE;
  }
  

  
  public function executeRemoveInactiveUsers(sfWebRequest $request)
  {
  	$c = new Criteria();
  	
  	$c->add(CustomerOrderPeer::CUSTOMER_ID, 
  		'customer_id IN (SELECT id FROM customer WHERE TIMESTAMPDIFF(MINUTE, NOW(), created_at) >= -30 AND customer_status_id = 1)'
  	, Criteria::CUSTOM);
  	
  	$this->remove_propel_object_list(CustomerOrderPeer::doSelect($c));
  	
  	//now transaction
  	$c = new Criteria();
  	
  	$c->add(TransactionPeer::CUSTOMER_ID, 
  		'customer_id IN (SELECT id FROM customer WHERE TIMESTAMPDIFF(MINUTE, NOW(), created_at) >= -30 AND customer_status_id = 1)'
  	, Criteria::CUSTOM);
  	
  	$this->remove_propel_object_list(TransactionPeer::doSelect($c));  	
  	
  	//now customer
   	$c = new Criteria();
  	
  	$c->add(CustomerPeer::ID, 
  		'id IN (SELECT id FROM customer WHERE TIMESTAMPDIFF(MINUTE, NOW(), created_at) >= -30 AND customer_status_id = 1)'
  	, Criteria::CUSTOM);
  	
  	$this->remove_propel_object_list(CustomerPeer::doSelect($c));  
  	
  	$this->renderText('last deleted on '. date(DATE_RFC822));
  	
  	return sfView::NONE;
  	 	
  }
  
  public function executeSMS(sfWebRequest $request)
  {
  	

  	$sms = SMS::receive($request);

  	if ($sms)
  	{
  		//take action
  		$valid_keywords = array('ZEROCALLS', 'ZEROCALLR', 'ZEROCALLN');
  		
  		if (in_array($sms->getKeyword(), $valid_keywords))
  		{
  			//get voucher info		  			
  			$c = new Criteria();
  			
  			$c->add(VoucherPeer::PIN_CODE, $sms->getMessage());
  			$c->add(VoucherPeer::USED_ON, null, CRITERIA::ISNULL);
  			
  			$is_voucher_ok = false;
  			$voucher = VoucherPeer::doSelectOne($c);
  			
  			switch (strtolower($sms->getKeyword()))
		  	{
		  		case 'zerocalls': //register + refill
		  			//purchaes a product in 0 rs, and 200 refill
		  			
		  			//create customer
		  			
		  			//create order for a product
		  			
		  			//don't create trnsaction for product order
		  			
		  			//create refill order for product
		  			//create transaction for refill order
		  			
		  			if ($voucher)
		  			{
		  				$is_voucher_ok = $voucher->getType()=='s';
		  				
		  				$is_voucher_ok = $is_voucher_ok &&
		  					 ($voucher->getAmount()==200);
		  			}
		  			
		  			if ($is_voucher_ok)
		  			{
		  				//check if customer already exists
		  				if ($this->is_mobile_number_exists($sms->getMobileNumber()))
		  				{
		  					$message = $this->getContext()->getI18N()->__('
		  						You mobile number is already registered with ZerOCall.
		  					');
		  					
		  					echo $message;
		  					SMS::send($message, $sms->getMobileNumber());
		  					break;
		  				}
			  			//create a customer
			  			$customer = new Customer();
			  			
			  			$customer->setMobileNumber($sms->getMobileNumber());
			  			$customer->setCountryId(83); //denmark;
			  			$customer->setAddress('Street address');
			  			$customer->setCity('City');
			  			$customer->setDeviceId(1);
			  			$customer->setEmail($sms->getMobileNumber().'@zerocall.com');
			  			$customer->setFirstName('First name');
			  			$customer->setLastName('Last name');
			  			
			  			$password  = substr(md5($customer->getMobileNumber() .  'jhom$brabar_x'),0,8);
			  			$customer->setPassword($password);
			  			
			  			//crete an order of startpackage
			  			$customer_order = new CustomerOrder();
			  			$customer_order->setCustomer($customer);
			  			$customer_order->setProductId(1);
			  			$customer_order->setExtraRefill($voucher->getAmount());
			  			$customer_order->setQuantity(0);
			  			$customer_order->setIsFirstOrder(true);
			  			
			  			//set customer_product
			  			
			  			$customer_product = new CustomerProduct();
			  			
			  			$customer_product->setCustomer($customer);
			  			$customer_product->setProduct($customer_order->getProduct());
			  			
			  			//crete a transaction of product price
			  			$transaction = new Transaction();
			  			$transaction->setAmount($voucher->getAmount());
			  			$transaction->setDescription($this->getContext()->getI18N()->__('Product  purchase & refill, via voucher'));
			  			$transaction->setOrderId($customer_order->getId());
			  			$transaction->setCustomer($customer);
			  			
			  			
			  			$customer->setCustomerStatusId(sfConfig::get('app_status_completed', 3));
			  			$customer_order->setOrderStatusId(sfConfig::get('app_status_completed', 3));
			  			$transaction->setTransactionStatusId(sfConfig::get('app_status_completed', 3));
			  			
			  			
			  			$customer->save();
			  			$customer_order->save();
			  			$customer_product->save();
			  			$transaction->save();
			  			
			  			
			  			//save voucher so it can't be reused
			  			$voucher->setUsedOn(date('Y-m-d'));
			  			
			  			$voucher->save();
			  			
			  			//register with fonet
			  			CustomerPeer::registerFonet($customer);
			  			CustomerPeer::recharge($customer, $transaction->getAmount());
			  			
			  			
			  			$message = $this->getContext()->getI18N()->__('
			  			You have been registered to ZerOcall.' /* \n
			  			You can use following login information to access your account.\n
			  			Email: '. $customer->getEmail(). '\n' .
			  			'Password: ' . $password */
			  			);
			  			
			  			echo $message;
			  			SMS::send($message, $customer->getMobileNumber());
			  			
			  				
		  			}
		  			else
		  			{
		  				$invalid_pin_sms = SMS::send($this->getContext()->getI18N()->__('Invalid pin code.'), $sms->getMobileNumber());
		  				echo $invalid_pin_sms;
		  				$this->logMessage('invaild pin sms sent to ' . $sms->getMobileNumber());
		  			}
		  			
		  			break;
		  		case 'zerocallr': //refill
		  			//check if mobile number exists?
		  			
		  			//create an order for sms refill
		  			
		  			//create a transaction
		  			if ($voucher)
		  			{
		  				$is_voucher_ok = $voucher->getType()=='r';

		  				$valid_refills = array(100, 200, 500);
		  				
		  				$is_voucher_ok = $is_voucher_ok && in_array($voucher->getAmount(), $valid_refills);
		  			}
		  			
		  			if ($is_voucher_ok)
		  			{
		  				//check if customer already exists
		  				if (!$this->is_mobile_number_exists($sms->getMobileNumber()))
		  				{
		  					$message = $this->getContext()->getI18N()->__('
		  						Your mobile number is not registered with ZerOCall.
		  					');
		  					
		  					echo $message;
		  					SMS::send($message, $sms->getMobileNumber());
		  					break;
		  				}
			  			//get the customer
			  			
		  				$c = new Criteria();
		  				$c->add(CustomerPeer::MOBILE_NUMBER, $sms->getMobileNumber());
		  				
		  				
			  			$customer = CustomerPeer::doSelectOne($c);
			  			
			  			//create new customer order
			  			$customer_order = new CustomerOrder();
			  			$customer_order->setCustomer($customer);

			  			//get customer product
			  			
			  			$c = new Criteria();
			  			$c->add(CustomerProductPeer::CUSTOMER_ID, $customer->getId());
			  			
			  			$customer_product = CustomerProductPeer::doSelectOne($c);
			  			
			  			//set customer product
			  			$customer_order->setProduct($customer_product->getProduct());
			  			
			  			$customer_order->setExtraRefill($voucher->getAmount());
			  			$customer_order->setQuantity(0);
			  			$customer_order->setIsFirstOrder(false);
			  			

			  			//crete a transaction of product price
			  			$transaction = new Transaction();
			  			$transaction->setAmount($voucher->getAmount());
			  			$transaction->setDescription($this->getContext()->getI18N()->__('Zerocall  Refill, via voucher'));
			  			$transaction->setOrderId($customer_order->getId());
			  			$transaction->setCustomer($customer);
			  			
			  			
			  			$customer_order->setOrderStatusId(sfConfig::get('app_status_completed', 3));
			  			$transaction->setTransactionStatusId(sfConfig::get('app_status_completed', 3));
			  			
			  			$customer_order->save();
			  			$transaction->save();
			  			
			  			CustomerPeer::recharge($customer, $transaction->getAmount());
			  			
			  			
			  			//save voucher so it can't be reused
			  			$voucher->setUsedOn(date('Y-m-d'));
			  			
			  			$voucher->save();
			  			
			  			$message = $this->getContext()->getI18N()->__('
			  			You account has been topped up.' /* \n
			  			You can use following login information to access your account.\n
			  			Email: '. $customer->getEmail(). '\n' .
			  			'Password: ' . $password */
			  			);
			  			
			  			echo $message;
			  			SMS::send($message, $sms->getMobileNumber());
			  			
			  				
		  			}
		  			else
		  			{
		  				$invalid_pin_sms = SMS::send($this->getContext()->getI18N()->__('Invalid pin code.'), $sms->getMobileNumber());
		  				echo $invalid_pin_sms;
		  				$this->logMessage('invaild pin sms sent to ' . $sms->getMobileNumber());
		  			}
		  			
		  			break;
		  		case 'zerocalln':
		  			//purchases a 100 product, no refill
		  			
		  			//check if pin code 
		  			// pin code matches
		  			// not used before
		  			//	type is n, amount eq to gt than product price
		  			
		  			

		  			if ($voucher)
		  			{
		  				$is_voucher_ok = $voucher->getType()=='n';
		  				
		  				$is_voucher_ok = $is_voucher_ok &&
		  					 ($voucher->getAmount()>=ProductPeer::retrieveByPK(1)->getPrice());
		  			}
		  			
		  			if ($is_voucher_ok)
		  			{
		  				//check if customer already exists
		  				if ($this->is_mobile_number_exists($sms->getMobileNumber()))
		  				{
		  					$message = $this->getContext()->getI18N()->__('
		  						You mobile number is already registered with ZerOCall.
		  					');
		  					
		  					echo $message;
		  					SMS::send($message, $sms->getMobileNumber());
		  					break;
		  				}
			  			//create a customer
			  			$customer = new Customer();
			  			
			  			$customer->setMobileNumber($sms->getMobileNumber());
			  			$customer->setCountryId(83); //denmark;
			  			$customer->setAddress('Street address');
			  			$customer->setCity('City');
			  			$customer->setDeviceId(1);
			  			$customer->setEmail($sms->getMobileNumber().'@zerocall.com');
			  			$customer->setFirstName('First name');
			  			$customer->setLastName('Last name');
			  			
			  			$password  = substr(md5($customer->getMobileNumber() .  'jhom$brabar_x'),0,8);
			  			$customer->setPassword($password);
			  			
			  			//crete an order of startpackage
			  			$customer_order = new CustomerOrder();
			  			$customer_order->setCustomer($customer);
			  			$customer_order->setProductId(1);
			  			$customer_order->setExtraRefill(0);
			  			$customer_order->setQuantity(1);
			  			$customer_order->setIsFirstOrder(true);
			  			
			  			//set customer_product
			  			
			  			$customer_product = new CustomerProduct();
			  			
			  			$customer_product->setCustomer($customer);
			  			$customer_product->setProduct($customer_order->getProduct());
			  			
			  			//crete a transaction of product price
			  			$transaction = new Transaction();
			  			$transaction->setAmount($customer_order->getProduct()->getPrice()*$customer_order->getQuantity());
			  			$transaction->setDescription($this->getContext()->getI18N()->__('Product  purchase, via voucher'));
			  			$transaction->setOrderId($customer_order->getId());
			  			$transaction->setCustomer($customer);
			  			
			  			
			  			$customer->setCustomerStatusId(sfConfig::get('app_status_completed', 3));
			  			$customer_order->setOrderStatusId(sfConfig::get('app_status_completed', 3));
			  			$transaction->setTransactionStatusId(sfConfig::get('app_status_completed', 3));
			  			
			  			
			  			$customer->save();
			  			$customer_order->save();
			  			$customer_product->save();
			  			$transaction->save();
			  			
			  			
			  			//save voucher so it can't be reused
			  			$voucher->setUsedOn(date('Y-m-d'));
			  			
			  			$voucher->save();
			  			
			  			//register with fonet
			  			CustomerPeer::registerFonet($customer);
			  			
			  			$message = $this->getContext()->getI18N()->__('
			  			You have been registered to ZerOcall.' /* \n
			  			You can use following login information to access your account.\n
			  			Email: '. $customer->getEmail(). '\n' .
			  			'Password: ' . $password */
			  			);
			  			
			  			echo $message;
			  			SMS::send($message, $sms->getMobileNumber());
			  			
			  				
		  			}
		  			else
		  			{
		  				$invalid_pin_sms = SMS::send($this->getContext()->getI18N()->__('Invalid pin code.'), $sms->getMobileNumber());
		  				echo $invalid_pin_sms;
		  				$this->logMessage('invaild pin sms sent to ' . $sms->getMobileNumber());
		  			}
		  			
		  			break;
		  	}  			
  		}
  		
  	}
  	
  	$this->renderText('completed');
  	
  	return sfView::NONE;	
  }
  
  private function is_mobile_number_exists($mobile_number)
  {
  	$c = new Criteria();
  	
  	$c->add(CustomerPeer::MOBILE_NUMBER, $mobile_number);
  	
  	 if (CustomerPeer::doSelectOne($c))
  	 	return true;
  }
  
  private function remove_propel_object_list($list)
  {
  	foreach($list as $list_item)
  	{
  		$list_item->delete();
  	}
  }

  public function executeSendEmails(sfWebRequest $request)
  {
  	
  require_once(sfConfig::get('sf_lib_dir').'/swift/lib/swift_init.php');
		
  	
  	$connection = Swift_SmtpTransport::newInstance()
			->setHost(sfConfig::get('app_email_smtp_host'))
			->setPort(sfConfig::get('app_email_smtp_port'))
			->setUsername(sfConfig::get('app_email_smtp_username'))
			->setPassword(sfConfig::get('app_email_smtp_password'));				

	$sender_email = sfConfig::get('app_email_sender_email', 'support@zerocall.com');
	$sender_name = sfConfig::get('app_email_sender_name', 'zerocall support');

	$mailer = new Swift_Mailer($connection);
		
  	$c = new Criteria();
  	
  	$c->add(EmailQueuePeer::EMAIL_STATUS_ID, sfConfig::get('app_status_completed'), Criteria::NOT_EQUAL);
  	
  	foreach(EmailQueuePeer::doSelect($c) as $email)
  	{		
		
		$message = Swift_Message::newInstance($email->getSubject())
		         ->setFrom(array($sender_email => $sender_name))
		         ->setTo(array($email->getReceipientEmail() => $email->getReceipientName()))
		         ->setBody($email->getMessage(), 'text/html')
		         ;
		         
		    
		         
		if (@$mailer->send($message))
		{
			$email->setEmailStatusId(sfConfig::get('app_status_completed'));
			//TODO:: add sent_at too
			$email->save();
			
			echo sprintf("Send to %s<br />", $email->getReceipientEmail());
		}
		
		
		         
  	}
  	return sfView::NONE;
  }
  
}