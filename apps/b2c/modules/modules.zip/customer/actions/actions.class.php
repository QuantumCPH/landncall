<?php

/**
 * customer actions.
 *
 * @package    zapnacrm
 * @subpackage customer
 * @author     Your name here
 * @version    SVN: $Id: actions.class.php,v 1.6 2010-08-18 06:06:23 orehman Exp $
 */
class customerActions extends sfActions
{
	public function executeTest(sfWebRequest $request)
	{
		
		$date1 = date('Y-m-d H:i:s', 1282293314);
		$date2 = date('Y-m-d H:i:s', 1282293431);
		
		echo sprintf('%s -- %s', $date1, $date2);
		
		echo '<br />';
		echo date('H:i:s', 1282293431-1282293314);
		
		exit;
		
		$customer = CustomerPeer::retrieveByPK(1);
		
		echo $customer->getMobileNumberWithCallingCode();
		exit;
		
		echo BaseUtil::trimMobileNumber(4520717786);
		
		exit;
		
		$customer = new Customer();
		$customer->setFonetCustomerId(1042453);
		$customer->setMobileNumber('77771111');
		
		var_dump(CustomerPeer::recharge($customer, -100, false));
		
		echo 'bal =  '.CustomerPeer::getBalance($customer, false).'<br />';
		exit;
		

		
		echo CustomerPeer::unregister($customer);
		//if (CustomerPeer::unregister($customer))
			//echo 'deleted '.$customer->getFonetCustomerId().'<br />';
				echo 'bal =  '.CustomerPeer::getBalance($customer).'<br />';
				exit;
		/*
		$c = new Criteria();
		$c->add(CustomerPeer::FONET_CUSTOMER_ID, null, CRITERIA::ISNOTNULL);
		
		foreach (CustomerPeer::doSelect($c) as $customer)
		{
			CustomerPeer::unregister($customer);
		}
		*/
		
		/*
		$c = new Criteria();

		foreach (FonetCustomerPeer::doSelect($c) as $fonet_customer)
		{
			$customer = new Customer();
			$customer->setFonetCustomerId($fonet_customer->getFonetCustomerId());
			
			if (CustomerPeer::unregister($customer))
				echo 'deleted '.$customer->getFonetCustomerId().'<br />';
		}
		exit;
		*/
		
		
		echo sha1('test1');
		exit;
		
		$order_amount = ((double)$request->getParameter('amount'))/100;
		
		var_dump($order_amount);
		
		exit;
		
		
		//exit;
		
		/*
		var_dump(CustomerPeer::registerFonet(
				CustomerPeer::retrieveByPK('84')
			)
		);
//		*/
			
		var_dump(CustomerPeer::recharge(
				CustomerPeer::retrieveByPK('84'),
				(string)$amount.'00'
			)
		);
		
		var_dump(CustomerPeer::getBalance(CustomerPeer::retrieveByPK('84')));
			
		
		return sfView::NONE;
		

 
		$sql = sprintf('CALL getRefferredTransactions(%s)', "1");		
		
		try
		{
			$pdo = Propel::getConnection();
			
			
			$st = $pdo->query($sql);
		
			$this->transactions = $st->fetchAll();
		}
		catch (Exception $e)
		{
			throw new sfException('Unable to fetch');
		}
		
		echo 'test';
		return sfView::NONE;
	}
	
  protected function processForm(sfWebRequest $request, sfForm $form)
  {
  	//print_r($request->getParameter($form->getName()));
  	
  	$customer = $request->getParameter($form->getName());
  	$product = $customer['product'];
  	
  	
    $form->bind($request->getParameter($form->getName()), $request->getFiles($form->getName()));
    
    if ($form->isValid())
    {
		
    
      $customer = $form->save();
      
      
      //$this->getUser()->setAttribute('customer_id', $customer->getId(), 'usersignup');
      //$this->getUser()->setAttribute('product_id', $product, 'usersignup');
      
      $this->redirect('@signup_step2?cid='.$customer->getId().'&pid='.$product);
      //$this->redirect(sfConfig::get('app_epay_relay_script_url').$this->getController()->genUrl('@signup_step2?customer_id='.$customer->getId().'&product_id='.$product, true));
    }
  }
  
  public function executeSignup(sfWebRequest $request){
  		$this->form = new CustomerFormB2C();
  		
  		//disable these fields for web registration
  		/*
  		unset(
  			$this->form['other'],
  			$this->form['subscription_type'],
  			$this->form['auto_refill']
  		);
		*/

  		//set referrer id
  		if ($referrer_id = $request->getParameter('ref'))
  		{
  			$c = new Criteria();
  			$c->add(AgentCompanyPeer::ID, $referrer_id);
 	
  			if (AgentCompanyPeer::doSelectOne($c))
  				$this->form->setDefault('referrer_id', $referrer_id);
  		}
  		
  		
  		
  		
  		if($request->isMethod('post')){
  			
  			$this->processForm($request, $this->form);
  		}
  	
  }
  
  public function executeChangePassword(sfWebRequest $request)
  {
  		echo 'Request to support@zerocall.com';
  		return sfView::NONE;
  }
  
  public function executeDashboard(sfWebRequest $request)
  {
  	
  	/*
  	$referer = $request->getReferer();
  	$referer = substr($referer, 0, stripos($referer, '?'));
  	
  	if($referer == $this->getController()->genUrl('@signup_step2', true) && $request->getParameter('customer_id') != ''){
  		$this->getUser()->setAuthenticated(true);
  		$this->getUser()->setAttribute('customer_id', $request->getParameter('customer_id'), 'usersession');
  		
  	} else if (!$this->getUser()->isAuthenticated()){
		$this->redirect('@b2c_homepage');  		
  	}
	*/
  	
  	$this->customer = CustomerPeer::retrieveByPK($this->getUser()->getAttribute('customer_id', '', 'usersession')); 
  	
  	$this->redirectUnless($this->customer, "@homepage");
  	
  	$this->customer_balance = -1;
  	
	//try to get balance again & again
	$num_tries = 3;
	
	for ($i=0; ($i < 3) && $this->customer_balance == -1 ; $i++)
	{
		$this->customer_balance = (double)CustomerPeer::getBalance($this->customer);
	}
	
	if ($this->customer_balance!=-1)
		$this->customer_balance = $this->customer_balance;
	
  }
  
	public function executeRefill(sfWebRequest $request)
	{
		//$this->redirectUnless($this->getUser()->isAuthenticated(),'@b2c_homepage');
		
		//$customer_id = $this->getUser()->getAttribute('customer_id',null, 'usersession');
		
		//TODO: authentication is missing
		
		$customer_id = $request->getParameter('customer_id');
		
		$this->customer = CustomerPeer::retrieveByPK($customer_id);
		
		$this->redirectUnless($this->customer, "@homepage");
		
		$this->form = new ManualRefillForm($customer_id);
		

		//new order
		$this->order = new CustomerOrder();
		
		$customer_products = $this->customer->getProducts();
		
		$this->order->setProduct($customer_products[0]);
		$this->order->setCustomer($this->customer);
		$this->order->setQuantity(0);
		$refills_options = ProductPeer::getRefillChoices();
		$this->order->setExtraRefill($refills_options[0]);
		$this->order->save();
		
		//new transaction
    	$transaction = new Transaction();
    	
    	$transaction->setAmount($this->order->getExtraRefill());
    	$transaction->setDescription($this->getContext()->getI18N()->__('Zerocall Refill'));
    	$transaction->setOrderId($this->order->getId());
    	$transaction->setCustomerId($this->order->getCustomerId());
    	
		//save
		$transaction->save();
	}
	
	public function executeRefillAccept(sfWebRequest $request)
	{
  	
	  	$order_id = $request->getParameter('orderid');
  		$order_amount = ((double)$request->getParameter('amount'))/100;
	  	
	  	$this->forward404Unless($order_id || $order_amount);
	  	
	
	  	$order = CustomerOrderPeer::retrieveByPK($order_id);
	  	
	  	$this->forward404Unless($order);
	  	
	  	$c = new Criteria;
	  	$c->add(TransactionPeer::ORDER_ID, $order_id);
	  	
	  	$transaction = TransactionPeer::doSelectOne($c);
	  	
	  	//echo var_dump($transaction);
	  	
	  	$order->setOrderStatusId(sfConfig::get('app_status_completed', 3)); //completed
	  	//$order->getCustomer()->setCustomerStatusId(sfConfig::get('app_status_completed', 3)); //completed
	  	$transaction->setTransactionStatusId(sfConfig::get('app_status_completed', 3)); //completed
	  	
	  	if($transaction->getAmount() > $order_amount){
	  		//error
	  		$order->setOrderStatusId(sfConfig::get('app_status_error', 5)); //error in amount
	  		$transaction->setTransactionStatusId(sfConfig::get('app_status_error', 5)); //error in amount
	  		//$order->getCustomer()->setCustomerStatusId(sfConfig::get('app_status_completed', 5)); //error in amount
	  		
	  	} else if ($transaction->getAmount() < $order_amount){
	  		//$extra_refill_amount = $order_amount;
	  		$order->setExtraRefill($order_amount);
	  		$transaction->setAmount($order_amount);
	  	} 
	  	
	  	
		 //set active agent_package in case customer
		  if ($order->getCustomer()->getAgentCompany())
		  {
		  	$order->setAgentCommissionPackageId($order->getCustomer()->getAgentCompany()->getAgentCommissionPackageId());
		  }
	  	
	  	$order->save();
	  	$transaction->save();
	  	

	
	$this->customer = $order->getCustomer();
	
	//TODO ask if recharge to be done is same as the transaction amount
	CustomerPeer::recharge($this->customer, $transaction->getAmount());
 	
	//set vat
	$vat = 0;
		
	//send email
  
  	$message_body = $this->getPartial('payments/order_receipt', array(
  						'customer'=>$this->customer,
  						'order'=>$order,
  						'transaction'=>$transaction,
  						'vat'=>$vat,
  						'wrap'=>false
  					));
  	
    $subject = $this->getContext()->getI18N()->__('Payment Confirmation');
	$sender_email = sfConfig::get('app_email_sender_email', 'support@zerocall.com');
	$sender_name = sfConfig::get('app_email_sender_name', 'zerocall support');

	$recepient_email = trim($this->customer->getEmail());
	$recepient_name = sprintf('%s %s', $this->customer->getFirstName(), $this->customer->getLastName());
	
	/*
  	require_once(sfConfig::get('sf_lib_dir').'/swift/lib/swift_init.php');
			
	$connection = Swift_SmtpTransport::newInstance()
				->setHost(sfConfig::get('app_email_smtp_host'))
				->setPort(sfConfig::get('app_email_smtp_port'))
				->setUsername(sfConfig::get('app_email_smtp_username'))
				->setPassword(sfConfig::get('app_email_smtp_password'));				
	
	$mailer = new Swift_Mailer($connection);
	
	$message_1 = Swift_Message::newInstance($subject)
	         ->setFrom(array($sender_email => $sender_name))
	         ->setTo(array($recepient_email => $recepient_name))
	         ->setBody($message_body, 'text/html')
	         ;
	         
	$message_2 = Swift_Message::newInstance($subject)
	         ->setFrom(array($sender_email => $sender_name))
	         ->setTo(array($sender_email => $sender_name))
	         ->setBody($message_body, 'text/html')
	         ;
	         
	if (!($mailer->send($message_1) && $mailer->send($message_2)))
	    $this->getUser()->setFlash('message', $this->getContext()->getI18N()->__(
	  		"Email confirmation is not sent" ));	
	*/
	
		//send to user
		$email = new EmailQueue();
	
		$email->setSubject($subject);
		$email->setReceipientName($recepient_name);
		$email->setReceipientEmail($recepient_email);
		$email->setMessage($message_body);
		
		$email->save();
		
		//send to support
		$email2 = new EmailQueue();
	
		$email2->setSubject($subject);
		$email2->setReceipientName($sender_name);
		$email2->setReceipientEmail($sender_email);
		$email2->setMessage($message_body);
		
		$email->save();
		//end send email
		  	
	  	$this->redirect('customer/dashboard');
	}
	
	public function executeRefillReject(sfWebRequest $request)
	{
		$order_id = $request->getParameter('orderid');
	    //$error_text = substr($request->getParameter('errortext'), 0, strpos($request->getParameter('errortext'), '!'));
    	$error_text = $this->getContext()->getI18N()->__('Payment is unfortunately not accepted because your 
    				information is incorrect, please try again by entering 
    				correct credit card information');
    	    
	  	$order = CustomerOrderPeer::retrieveByPK($order_id);
	  	$c = new Criteria();
	  	$c->add(TransactionPeer::ORDER_ID, $order_id);
	  	$transaction = TransactionPeer::doSelectOne($c);
	  	
	  	$this->forward404Unless($order);
	  	
	  	$order->setOrderStatusId(sfConfig::get('app_status_cancelled')); //cancelled
	  	
	  	$this->getUser()->setFlash('error_message', 
	  					$error_text
	  					);
	  					
	  	$this->order = $order;
	  	$this->forward404Unless($this->order);
	  	
	  	//required for some templates
	  	$this->customer = $this->order->getCustomer();
	  	
	  	$this->order_id = $order->getId();
	    $this->amount   = $transaction->getAmount();
	    $this->form     = new ManualRefillForm($this->order->getCustomerId());
	    $this->setTemplate('refill');	
	}
	
	
	public function executeCallhistory(sfWebRequest $request)
	{
		//$this->customer = CustomerPeer::retrieveByPK(58);
		$this->customer = CustomerPeer::retrieveByPK(
			$this->getUser()->getAttribute('customer_id', null, 'usersession')
			);
		$this->redirectUnless($this->customer, "@homepage");
		
		$c = new Criteria();
		$c->add(ZerocallCdrPeer::ANI, BaseUtil::trimMobileNumber($this->customer->getMobileNumber()));
		$c->add(ZerocallCdrPeer::SOURCECTY, $this->customer->getCountry()->getCallingCode());	
		$c->add(ZerocallCdrPeer::USEDVALUE, 0, Criteria::NOT_EQUAL);
		$c->addDescendingOrderByColumn(ZerocallCdrPeer::ANSWERTIMEB);

		//setting filter
		$this->filter = new ZerocallCdrFormFilter();
		
		if ($request->getParameter('zerocall_cdr_log_filters'))
		{			
			$c->add($this->filter->buildCriteria($request->getParameter('zerocall_cdr_log_filters')));
			//$this->filter->bind($request->getParameter('zerocall_cdr_log_filters'));
		}
		
		//set paging
		$items_per_page = 10; //shouldn't be 0
		$this->page = $request->getParameter('page');
        if($this->page == '') $this->page = 1;

        $pager = new sfPropelPager('ZerocallCdr', $items_per_page);
        $pager->setPage($this->page);

        $pager->setCriteria($c);

        $pager->init();

        $this->callRecords = $pager->getResults();
		$this->total_pages = $pager->getNbResults() / $items_per_page;
	
	}
	
	public function executePaymenthistory(sfWebRequest $request)
	{
		//$this->customer = CustomerPeer::retrieveByPK(58);
		
		$this->customer = CustomerPeer::retrieveByPK(
			$this->getUser()->getAttribute('customer_id', null, 'usersession')
			);
		
		$this->redirectUnless($this->customer, "@homepage");
		
		//get  transactions
		$c = new Criteria();
		
		$c->add(TransactionPeer::CUSTOMER_ID, $this->customer->getId());
		$c->add(TransactionPeer::TRANSACTION_STATUS_ID, 
				sfConfig::get('app_status_completed', -1)
				);
		/*
		if (isset($request->getParameter('filter')))
		{
			$filter = $request->getParameter('filter');
			
			$phone_number = isset($filter['phone_number'])?$filter['phone_number']:null;

			$from_date = isset($filter['from_date'])?$filter['from_date']:null;
			$to_date = isset($filter['to_date'])?$filter['to_date']:null;
		
			if ($phone_number)
				$c->add(CustomerPeer::MOBILE_NUMBER, $phone_number);
			if ($from_date)
				$c->add(TransactionPeer::CREATED_AT, $from_date, Criteria::GREATER_EQUAL);
			if ($to_date && !$from_date)
				$c->add(TransactionPeer::CREATED_AT, $to_date . ' 23:59:59', Criteria::LESS_EQUAL);
			elseif ($to_date && $from_date)
				$c->addAnd(TransactionPeer::CREATED_AT, $to_date . ' 23:59:59', Criteria::LESS_EQUAL);
			
		}
		*/
		
		$c->addDescendingOrderByColumn(TransactionPeer::CREATED_AT);

		//set paging
		$items_per_page = 10; //shouldn't be 0
		$this->page = $request->getParameter('page');
        if($this->page == '') $this->page = 1;

        $pager = new sfPropelPager('Transaction', $items_per_page);
        $pager->setPage($this->page);

        $pager->setCriteria($c);

        $pager->init();

        $this->transactions = $pager->getResults();
		$this->total_pages = $pager->getNbResults() / $items_per_page;
		
		
	
	}
	
	public function executeSettings(sfWebRequest $request)
	{
		$this->redirectUnless($this->getUser()->isAuthenticated(), "@homepage");
		//$this->customer = CustomerPeer::retrieveByPK(58);
		$this->customer = CustomerPeer::retrieveByPK(
			$this->getUser()->getAttribute('customer_id', null, 'usersession')
			);
		//$this->forward404Unless($this->customer);
		$this->redirectUnless($this->customer, "@homepage");

		$this->form = new CustomerFormSettings(CustomerPeer::retrieveByPK($this->customer->getId()));	  	
	  		
  		if($request->isMethod('post')){
  		    $this->form->bind($request->getParameter($this->form->getName()), $request->getFiles($this->form->getName()));
		    if ($this->form->isValid())
		    {
		   		
		      $customer = $this->form->save();
 
		      $this->getUser()->setFlash('message', 'Your settings have been saved.');
		    }
  		}
		

		
	  	//disable
	  	//$this->form->widgetSchema['mobile_number']->setAttribute('readonly','readonly');
	  	$this->form->getWidget('mobile_number')->setAttribute('readonly','readonly');
	  	//$this->form->getWidget('mobile_number')->setAttribute('disabled','disabled');
	  	$this->form->getWidget('email')->setAttribute('readonly','readonly');
	  	//$this->form->getWidget('email')->setAttribute('disabled','disabled');
	  	//$this->getValidator['mobile_number'] = new sfValidatorReadOnlyField(array('field' => 'mobile_number', 'object' => $this->form->getObject()));


	  	
	  	//$this->form->getWidget('password')->setOption('always_render_empty', false);
	  	//$this->form->getWidget('password_confirm')->setOption('always_render_empty', false);
	  	

	  	//get default pre-requisites
	  	$c = new Criteria();
	  	$c->add(DevicePeer::ID, $this->customer->getDeviceId());
	  	
	  	$device = DevicePeer::doSelectOne($c);
	  	
	  	$manufacturer = $device->getManufacturer();
	  	
	  	$this->form->setDefault(
	  			'manufacturer', $manufacturer->getId()
	  	);


	}
  
  public function executeLogin(sfWebRequest $request)
  {
  	
  	if ($request->isMethod('post') && 
  		$request->getParameter('mobile_number')!='' && 
  		$request->getParameter('password')!='')
  	{
	  	$mobile_number = $request->getParameter('mobile_number');
	  	$password = sha1($request->getParameter('password'));
	  	
	  	$c = new Criteria();
	  	$c->add(CustomerPeer::MOBILE_NUMBER, $mobile_number);
	  	$c->add(CustomerPeer::PASSWORD, $password);
	  	$c->add(CustomerPeer::CUSTOMER_STATUS_ID, sfConfig::get('app_status_completed'));
	  	
	  	$customer = CustomerPeer::doSelectOne($c);
	  	

	  	if ($customer)
	  	{
	  		$this->getUser()->setAttribute('customer_id', $customer->getId(), 'usersession');
	  		$this->getUser()->setAuthenticated(true);
	  		
	  		//$this->redirect('@customer_dashboard');
	  		if ($request->isXmlHttpRequest())
	  			$this->renderText('ok');
	  		else
	  		{
	  			$this->redirect('customer/dashboard');
	  		}
	  	}
	  	else
	  	{
	  		//
	  		if ($request->isXmlHttpRequest())
	  			$this->renderText('invalid');
	  		else
	  		{
	  			$this->getUser()->setFlash('error_message', 'Invaild mobile number or password.');
	  		}
	  	}
  	}
  	else
  	{
  		if ($request->isXmlHttpRequest())
  		{
  			$this->renderPartial('login');
  			return sfView::NONE;
  		}
  	}
  }
  
  public function executeLogout(sfWebRequest $request)
  {
  
  	$this->getUser()->getAttributeHolder()->removeNameSpace('usersession');
  	$this->getUser()->setAuthenticated(false);
  	$this->redirect('@b2c_homepage');
  	
  	return sfView::NONE;
  }
  
  public function executeSendPassword(sfWebRequest $request)
  {
  	
  	//$this->forward404Unless($request->isMethod('post'));
  	$this->redirectUnless($request->isMethod('post'), "@homepage");
  	
  	$c = new Criteria();
  	
  	$c->add(CustomerPeer::EMAIL, $request->getParameter('email'));
  	$c->add(CustomerPeer::CUSTOMER_STATUS_ID, sfConfig::get('app_status_completed'));
  	
  	$customer = CustomerPeer::doSelectOne($c);
  	
  	if ($customer)
  	{
  		//change the password to some thing uniuque and complex
  		$new_password = substr(base64_encode($customer->getPassword()),0,8);
  		
  		$customer->setPassword(sha1($new_password));
  		
  		$message_body = $this->getContext()->getI18N()->__('Hi'). ' ' . $customer->getFirstName().'!';
  		$message_body .= '<br /><br />';
  		$message_body .= $this->getContext()->getI18N()->__('Your password has been changed. Please use the following information to login to your zer0call account.');
  		$message_body .= '<br /><br />';
  		$message_body .= sprintf('Email: %s', $customer->getEmail());
  		$message_body .= '<br />';
  		$message_body .= $this->getContext()->getI18N()->__('Password'). ': '.$new_password;
  		
  		$customer->save();
  		
  		//$this->renderText($message_body);
  		//send email
  	
  		
  	    $subject = $this->getContext()->getI18N()->__('Password Request');
		$sender_email = sfConfig::get('app_email_sender_email', 'support@zerocall.com');
		$sender_name = sfConfig::get('app_email_sender_name', 'zerocall support');

		$recepient_email = trim($customer->getEmail());
		$recepient_name = sprintf('%s %s', $customer->getFirstName(), $customer->getLastName());
		
  		require_once(sfConfig::get('sf_lib_dir').'/swift/lib/swift_init.php');
				
		$connection = Swift_SmtpTransport::newInstance()
					->setHost(sfConfig::get('app_email_smtp_host', 'localhost'))
					->setPort(sfConfig::get('app_email_smtp_port', '25'))
					->setUsername(sfConfig::get('app_email_smtp_username'))
					->setPassword(sfConfig::get('app_email_smtp_password'));				
		
		$mailer = new Swift_Mailer($connection);
		
		$message = Swift_Message::newInstance($subject)
		         ->setFrom(array($sender_email => $sender_name))
		         ->setTo(array($recepient_email => $recepient_name))
		         ->setBody($message_body, 'text/html')
		         ;
		         
		 
		if ($mailer->send($message))
			if ($request->isXmlHttpRequest())
			{
			 	$this->renderText('ok');
			 	return sfView::NONE;
			}
			else
			{
	  			$this->getUser()->setFlash('send_password_message', 'Your account details have been sent to your email address.');	
			}
		else
			if ($request->isXmlHttpRequest())
			{
				$this->renderText('invalid');
				return sfView::NONE;
			}
			else
			{
	  			$this->getUser()->setFlash('send_password_error_message', 'Unable to send details at your email. Please try again later.');
			}
  	}
  	else
  	{
		if ($request->isXmlHttpRequest())
		{
  			$this->renderText('invalid');
  			return sfView::NONE;
		}
		else
		{
	  		$this->getUser()->setFlash('send_password_error_message', 'No customer is registered with this email.');
		}
  	} //end if	
  	
  	//return $this->forward('customer', 'login');
  	return $this->redirect('customer/login');
  } //end funcition
  
  
  public function executeGetHeader()
  {
  	echo $this->getPartial("header", array('test_dir'=>'/testwp'));
  	sfConfig::set('sf_web_debug', false);
  	return sfView::NONE;
  	
  }
  
}
