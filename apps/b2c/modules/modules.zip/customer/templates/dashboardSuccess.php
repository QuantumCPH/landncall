<?php use_helper('I18N') ?>
<?php use_helper('Number') ?>
<?php include_partial('dashboard_header', array('customer'=> $customer, 'section'=>__('Dashboard')) ) ?>
  <div class="left-col">
    <?php include_partial('navigation', array('selected'=>'dashboard', 'customer_id'=>$customer->getId())) ?>
    <div class="dashboard-info">
<div class="fl cb dashboard-info-text"><span><?php echo __('Account') ?>:</span><span><?php echo $customer->getMobileNumber() ?></span></div>
<div class="fl cb dashboard-info-text"><span><?php echo __('Your account balance is') ?>:</span><span><?php echo $customer_balance==-1?'&oslash;':format_number($customer_balance) ?> dkk</span></div>
<div class="fl cb"><button onclick="window.location.href='<?php echo sfConfig::get('app_epay_relay_script_url').url_for('customer/refill?customer_id='.$customer->getId(), true) ?>'"><?php echo __('Buy credit') ?></button></div>
    </div>
  </div>

  <?php include_partial('sidebar') ?>
  <iframe src="http://zerocall.com/b2c/testc.php" style="display:none"></iframe>