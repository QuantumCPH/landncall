<?php
/*
  <div class="right-col">
    <div class="box box-b">
      <h3>Zapna Call<span>All</span></h3>
      <small>Ring billigt over hele verden</small>
      <p>Luda esse singularis simmilas
        vector ludo prosint nunc pro
        exreas...</p>
      <a href="#" class="more"><span>L�s og bestil &raquo;</span></a> </div>

  </div>
*/?>
  
<!-- new sidebar -->

<div id="sidebar" role="complementary">

	<div class="right-col">
		<div class="box box-0">
			<h3>Gratis lande</h3>
			<p>Opkald til 60 destinationer til 0 &oslash;re* Med zerOcall Free beh&oslash;ver 
du ikke at tilmelde dig,</p>
			<a href="http://zerocall.com/testwp/?page_id=64" rel="bookmark" title="Gratis lande"><span>L&aelig;s og bestil &raquo;</span></a>
		</div>
		
		<div class="box box-1">
			<h3>Tip en ven</h3>
			<p>Internationale opkald fra 0 &oslash;re* Med zerOcall Out kan du ringe til hele 
  verden til de</p>
			<a title="Tip en ven" rel="bookmark" href="http://zerocall.com/testwp/?page_id=51"><span>L&aelig;s og bestil &raquo;</span></a>
		</div>
	</div>
</div>