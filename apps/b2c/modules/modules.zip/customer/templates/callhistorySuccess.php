<?php use_helper('I18N') ?>
<?php use_helper('Number') ?>
<?php include_partial('dashboard_header', array('customer'=> $customer, 'section'=>__('Call History')) ) ?>
<div class="alert_bar">
	<?php echo __('Call history is updated after every 5-10 minutes.') ?>
</div>
  <div class="left-col">
    <?php include_partial('navigation', array('selected'=>'callhistory', 'customer_id'=>$customer->getId())) ?>
	<div class="split-form">
      <div class="fl col">
        <form action="<?php echo url_for('customer/callhistory') ?>" method="post">
          <ul>
<?php /*
            <li>
              <label><?php echo $filter['to_no']->renderLabel() ?>:</label>
              <?php echo $filter['to_no'] ?>
            </li>
            <li>
            	<?php echo $filter['date']->render(array('class' => 'quater')) ?>
            </li>
            <!-- 
            <li>
              <label><?php echo __('From') ?>:</label>
              <select class="quater">
                <option>&nbsp;</option>
              </select>
              <select class="quater">
                <option>&nbsp;</option>
              </select>
              <select class="quater">
                <option>&nbsp;</option>
              </select>
            </li>
            
            <li>
              <label><?php echo __('To') ?>:</label>
              <select class="quater">
                <option>&nbsp;</option>
              </select>
              <select class="quater">
                <option>&nbsp;</option>
              </select>
              <select class="quater">
                <option>&nbsp;</option>
              </select>
            </li>
             -->
            <li>
              <button><?php echo __('Show') ?></button>
            </li>
 */ ?>
            <li>
              <!--Always use tables for tabular data-->
			<table width="100%" border="0" cellspacing="0" cellpadding="0" class="callhistory">
                  <tr>
                    <td class="title"><?php echo __('Date &amp; time') ?></td>
                    <td class="title" width="40%"><?php echo __('Phone Number') ?></td>
                    <td class="title"><?php echo __('Duration') ?></td>
                    <!-- 
                    <td class="title"><?php echo __('Cost <small>(Ex. VAT)</small>') ?></td>
                     -->
                    <td class="title"><?php echo __('Cost <small>(Incl. VAT)</small>') ?></td>
                  </tr>

                <?php 
                $amount_total = 0;
                foreach($callRecords as $callRecord): ?>
                <tr>
                  <td><?php  echo date('Y-m-d H:i:s', $callRecord->getAnswertimeb()) ?></td>
                  <td><?php echo  $callRecord->getExtension() ?></td>
                  <td><?php echo date('H:i:s', $callRecord->getEndtimeb() - $callRecord->getAnswertimeb() - 3600*2 ) ?></td>
                  <!--  
                  <td><?php echo format_number($callRecord->getUsedvalue() - $callRecord->getUsedvalue()*.20) ?> dkk</td>
                  -->
                  <td><?php $amount_total += $callRecord->getUsedvalue()/100; echo format_number($callRecord->getUsedvalue()/100) ?> dkk</td>
                </tr>
                <?php endforeach; ?>
                <?php if(count($callRecords)==0): ?>
                <tr>
                	<td colspan="5"><p><?php echo __('There are currently no call records to show.') ?></p></td>
                </tr>
                <?php else: ?>
                <tr>
                	<td colspan="3" align="right"><strong><?php echo __('Subtotal') ?></strong></td>
                	<!--
                	<td><?php echo format_number($amount_total-$amount_total*.20) ?> dkk</td>
                	 -->
                	<td><?php echo format_number($amount_total) ?> dkk</td>
                </tr>	
                <?php endif; ?>
              </table>
            </li>
            <?php if($total_pages>1): ?>
            <li>
            	<ul class="paging">
            	<?php for ($i=1; $i<=$total_pages; $i++): ?>
            		<li <?php echo $i==$page?'class="selected"':'' ?>><a href="<?php echo url_for('customer/callhistory?page='.$i) ?>"><?php echo $i ?></a></li>
            	<?php endfor; ?>
            	</ul>
            </li>
            <?php endif; ?>
          </ul>
        </form>
      </div>
    </div> <!-- end split-form -->
  </div> <!-- end left-col -->
  <?php include_partial('sidebar') ?>