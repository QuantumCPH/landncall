  <div id="inner-page" class="dashboard">
    <h2><?php echo __('Welcome') ?> <?php echo $customer?($customer->getFirstName().' '.$customer->getLastName()):'' ?> - <span><?php echo $section ?></span></h2>
  </div>