<?php use_helper('I18N') ?>
<script language="javascript">
		jQuery(document).ready(function(){
		jQuery('#nav2>li.current_page_item ul, #nav2>li.current_page_ancestor ul').css('display','block');
		jQuery('#nav2>li').hover(function(){
			jQuery('#nav2 li ul').css('display','none');
			jQuery(this).children('ul').css('display','block');
		});
		
		jQuery('#nav2').mouseout(function(){
			setTimeout( function(){
				jQuery('#nav2 li ul').fadeOut('fast')
				}, 20000 );
		});
	});
</script>
      <ul id="nav2" class="clearfloat">
         <?php
		 echo file_get_contents('http://zerocall.com/?page_id=332');

         if (!$sf_user->isAuthenticated()):
          ?>
			<li><a href="<?php echo url_for('@signup_step1', true) ?>"><?php echo __('Sign up') ?></a></li>
         	<li class="last"><a href="<?php echo url_for('customer/login', true) ?>" id="login_link"><?php echo __('Login') ?></a></li>
         <?php else: ?>
	     	<li><a href="<?php echo url_for('customer/dashboard', true) ?>"><?php echo __('My Account') ?></a></li>
         	<li class="last"><a href="<?php echo url_for('customer/logout', true) ?>"><?php echo __('Logout') ?></a></li>        
         <?php endif; ?>
      </ul>